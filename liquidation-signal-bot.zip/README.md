# Liquidation Signal Bot (Free API + Coinglass Support)
Bu bot tamamen ücretsiz Binance verileri + opsiyonel Coinglass kullanarak liquidation tabanlı sinyal üretir.
